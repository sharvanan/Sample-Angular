package com.sample.ty.my_app.repos;

import com.sample.ty.my_app.domain.ComponentType;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ComponentTypeRepository extends JpaRepository<ComponentType, Long> {
}
