package com.sample.ty.my_app.repos;

import com.sample.ty.my_app.domain.Deployment;
import com.sample.ty.my_app.domain.Instance;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DeploymentRepository extends JpaRepository<Deployment, Long> {

    Deployment findFirstByInstance(Instance instance);

    Deployment findFirstByDeploymentsAndIdNot(Deployment deployment, final Long id);

    List<Deployment> findAllByDeployments(Deployment deployment);

}
