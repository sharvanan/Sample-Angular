package com.sample.ty.my_app.service;

import com.sample.ty.my_app.domain.Component;
import com.sample.ty.my_app.domain.Deployment;
import com.sample.ty.my_app.domain.Instance;
import com.sample.ty.my_app.model.DeploymentDTO;
import com.sample.ty.my_app.repos.ComponentRepository;
import com.sample.ty.my_app.repos.DeploymentRepository;
import com.sample.ty.my_app.repos.InstanceRepository;
import com.sample.ty.my_app.util.NotFoundException;
import com.sample.ty.my_app.util.ReferencedWarning;
import jakarta.transaction.Transactional;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
@Transactional
public class DeploymentService {

    private final DeploymentRepository deploymentRepository;
    private final InstanceRepository instanceRepository;
    private final ComponentRepository componentRepository;

    public DeploymentService(final DeploymentRepository deploymentRepository,
            final InstanceRepository instanceRepository,
            final ComponentRepository componentRepository) {
        this.deploymentRepository = deploymentRepository;
        this.instanceRepository = instanceRepository;
        this.componentRepository = componentRepository;
    }

    public List<DeploymentDTO> findAll() {
        final List<Deployment> deployments = deploymentRepository.findAll(Sort.by("id"));
        return deployments.stream()
                .map(deployment -> mapToDTO(deployment, new DeploymentDTO()))
                .toList();
    }

    public DeploymentDTO get(final Long id) {
        return deploymentRepository.findById(id)
                .map(deployment -> mapToDTO(deployment, new DeploymentDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final DeploymentDTO deploymentDTO) {
        final Deployment deployment = new Deployment();
        mapToEntity(deploymentDTO, deployment);
        return deploymentRepository.save(deployment).getId();
    }

    public void update(final Long id, final DeploymentDTO deploymentDTO) {
        final Deployment deployment = deploymentRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(deploymentDTO, deployment);
        deploymentRepository.save(deployment);
    }

    public void delete(final Long id) {
        final Deployment deployment = deploymentRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        // remove many-to-many relations at owning side
        deploymentRepository.findAllByDeployments(deployment)
                .forEach(deployment -> deployment.getDeployments().remove(deployment));
        deploymentRepository.delete(deployment);
    }

    private DeploymentDTO mapToDTO(final Deployment deployment, final DeploymentDTO deploymentDTO) {
        deploymentDTO.setId(deployment.getId());
        deploymentDTO.setName(deployment.getName());
        deploymentDTO.setInstance(deployment.getInstance() == null ? null : deployment.getInstance().getId());
        deploymentDTO.setDeployments(deployment.getDeployments().stream()
                .map(deploymentInt -> deploymentInt.getId())
                .toList());
        return deploymentDTO;
    }

    private Deployment mapToEntity(final DeploymentDTO deploymentDTO, final Deployment deployment) {
        deployment.setName(deploymentDTO.getName());
        final Instance instance = deploymentDTO.getInstance() == null ? null : instanceRepository.findById(deploymentDTO.getInstance())
                .orElseThrow(() -> new NotFoundException("instance not found"));
        deployment.setInstance(instance);
        final List<Deployment> deployments = deploymentRepository.findAllById(
                deploymentDTO.getDeployments() == null ? Collections.emptyList() : deploymentDTO.getDeployments());
        if (deployments.size() != (deploymentDTO.getDeployments() == null ? 0 : deploymentDTO.getDeployments().size())) {
            throw new NotFoundException("one of deployments not found");
        }
        deployment.setDeployments(new HashSet<>(deployments));
        return deployment;
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Deployment deployment = deploymentRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Component deploymentComponent = componentRepository.findFirstByDeployment(deployment);
        if (deploymentComponent != null) {
            referencedWarning.setKey("deployment.component.deployment.referenced");
            referencedWarning.addParam(deploymentComponent.getId());
            return referencedWarning;
        }
        return null;
    }

}
