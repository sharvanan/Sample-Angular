package com.sample.ty.my_app.rest;

import com.sample.ty.my_app.domain.ComponentType;
import com.sample.ty.my_app.domain.Deployment;
import com.sample.ty.my_app.model.ComponentDTO;
import com.sample.ty.my_app.repos.ComponentTypeRepository;
import com.sample.ty.my_app.repos.DeploymentRepository;
import com.sample.ty.my_app.service.ComponentService;
import com.sample.ty.my_app.util.CustomCollectors;
import com.sample.ty.my_app.util.ReferencedException;
import com.sample.ty.my_app.util.ReferencedWarning;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/components", produces = MediaType.APPLICATION_JSON_VALUE)
public class ComponentResource {

    private final ComponentService componentService;
    private final DeploymentRepository deploymentRepository;
    private final ComponentTypeRepository componentTypeRepository;

    public ComponentResource(final ComponentService componentService,
            final DeploymentRepository deploymentRepository,
            final ComponentTypeRepository componentTypeRepository) {
        this.componentService = componentService;
        this.deploymentRepository = deploymentRepository;
        this.componentTypeRepository = componentTypeRepository;
    }

    @GetMapping
    public ResponseEntity<List<ComponentDTO>> getAllComponents() {
        return ResponseEntity.ok(componentService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ComponentDTO> getComponent(@PathVariable(name = "id") final Long id) {
        return ResponseEntity.ok(componentService.get(id));
    }

    @PostMapping
    @ApiResponse(responseCode = "201")
    public ResponseEntity<Long> createComponent(
            @RequestBody @Valid final ComponentDTO componentDTO) {
        final Long createdId = componentService.create(componentDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Long> updateComponent(@PathVariable(name = "id") final Long id,
            @RequestBody @Valid final ComponentDTO componentDTO) {
        componentService.update(id, componentDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    @ApiResponse(responseCode = "204")
    public ResponseEntity<Void> deleteComponent(@PathVariable(name = "id") final Long id) {
        final ReferencedWarning referencedWarning = componentService.getReferencedWarning(id);
        if (referencedWarning != null) {
            throw new ReferencedException(referencedWarning);
        }
        componentService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/deploymentValues")
    public ResponseEntity<Map<Long, String>> getDeploymentValues() {
        return ResponseEntity.ok(deploymentRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Deployment::getId, Deployment::getName)));
    }

    @GetMapping("/componentTypeValues")
    public ResponseEntity<Map<Long, String>> getComponentTypeValues() {
        return ResponseEntity.ok(componentTypeRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(ComponentType::getId, ComponentType::getName)));
    }

}
