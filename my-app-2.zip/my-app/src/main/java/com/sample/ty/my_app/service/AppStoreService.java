package com.sample.ty.my_app.service;

import com.sample.ty.my_app.domain.AppStore;
import com.sample.ty.my_app.model.AppStoreDTO;
import com.sample.ty.my_app.repos.AppStoreRepository;
import com.sample.ty.my_app.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class AppStoreService {

    private final AppStoreRepository appStoreRepository;

    public AppStoreService(final AppStoreRepository appStoreRepository) {
        this.appStoreRepository = appStoreRepository;
    }

    public List<AppStoreDTO> findAll() {
        final List<AppStore> appStores = appStoreRepository.findAll(Sort.by("id"));
        return appStores.stream()
                .map(appStore -> mapToDTO(appStore, new AppStoreDTO()))
                .toList();
    }

    public AppStoreDTO get(final Long id) {
        return appStoreRepository.findById(id)
                .map(appStore -> mapToDTO(appStore, new AppStoreDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final AppStoreDTO appStoreDTO) {
        final AppStore appStore = new AppStore();
        mapToEntity(appStoreDTO, appStore);
        return appStoreRepository.save(appStore).getId();
    }

    public void update(final Long id, final AppStoreDTO appStoreDTO) {
        final AppStore appStore = appStoreRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(appStoreDTO, appStore);
        appStoreRepository.save(appStore);
    }

    public void delete(final Long id) {
        appStoreRepository.deleteById(id);
    }

    private AppStoreDTO mapToDTO(final AppStore appStore, final AppStoreDTO appStoreDTO) {
        appStoreDTO.setId(appStore.getId());
        appStoreDTO.setName(appStore.getName());
        appStoreDTO.setType(appStore.getType());
        appStoreDTO.setContinuity(appStore.getContinuity());
        appStoreDTO.setIntegrity(appStore.getIntegrity());
        appStoreDTO.setTraceability(appStore.getTraceability());
        appStoreDTO.setAvailability(appStore.getAvailability());
        return appStoreDTO;
    }

    private AppStore mapToEntity(final AppStoreDTO appStoreDTO, final AppStore appStore) {
        appStore.setName(appStoreDTO.getName());
        appStore.setType(appStoreDTO.getType());
        appStore.setContinuity(appStoreDTO.getContinuity());
        appStore.setIntegrity(appStoreDTO.getIntegrity());
        appStore.setTraceability(appStoreDTO.getTraceability());
        appStore.setAvailability(appStoreDTO.getAvailability());
        return appStore;
    }

    public boolean nameExists(final String name) {
        return appStoreRepository.existsByNameIgnoreCase(name);
    }

}
