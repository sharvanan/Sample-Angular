package com.sample.ty.my_app.service;

import com.sample.ty.my_app.domain.Component;
import com.sample.ty.my_app.domain.Status;
import com.sample.ty.my_app.model.StatusDTO;
import com.sample.ty.my_app.repos.ComponentRepository;
import com.sample.ty.my_app.repos.StatusRepository;
import com.sample.ty.my_app.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class StatusService {

    private final StatusRepository statusRepository;
    private final ComponentRepository componentRepository;

    public StatusService(final StatusRepository statusRepository,
            final ComponentRepository componentRepository) {
        this.statusRepository = statusRepository;
        this.componentRepository = componentRepository;
    }

    public List<StatusDTO> findAll() {
        final List<Status> statuses = statusRepository.findAll(Sort.by("id"));
        return statuses.stream()
                .map(status -> mapToDTO(status, new StatusDTO()))
                .toList();
    }

    public StatusDTO get(final Long id) {
        return statusRepository.findById(id)
                .map(status -> mapToDTO(status, new StatusDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final StatusDTO statusDTO) {
        final Status status = new Status();
        mapToEntity(statusDTO, status);
        return statusRepository.save(status).getId();
    }

    public void update(final Long id, final StatusDTO statusDTO) {
        final Status status = statusRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(statusDTO, status);
        statusRepository.save(status);
    }

    public void delete(final Long id) {
        statusRepository.deleteById(id);
    }

    private StatusDTO mapToDTO(final Status status, final StatusDTO statusDTO) {
        statusDTO.setId(status.getId());
        statusDTO.setName(status.getName());
        statusDTO.setComponent(status.getComponent() == null ? null : status.getComponent().getId());
        return statusDTO;
    }

    private Status mapToEntity(final StatusDTO statusDTO, final Status status) {
        status.setName(statusDTO.getName());
        final Component component = statusDTO.getComponent() == null ? null : componentRepository.findById(statusDTO.getComponent())
                .orElseThrow(() -> new NotFoundException("component not found"));
        status.setComponent(component);
        return status;
    }

}
