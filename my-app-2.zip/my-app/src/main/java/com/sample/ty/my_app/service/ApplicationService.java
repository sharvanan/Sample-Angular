package com.sample.ty.my_app.service;

import com.sample.ty.my_app.domain.Application;
import com.sample.ty.my_app.domain.Instance;
import com.sample.ty.my_app.model.ApplicationDTO;
import com.sample.ty.my_app.repos.ApplicationRepository;
import com.sample.ty.my_app.repos.InstanceRepository;
import com.sample.ty.my_app.util.NotFoundException;
import com.sample.ty.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final InstanceRepository instanceRepository;

    public ApplicationService(final ApplicationRepository applicationRepository,
            final InstanceRepository instanceRepository) {
        this.applicationRepository = applicationRepository;
        this.instanceRepository = instanceRepository;
    }

    public List<ApplicationDTO> findAll() {
        final List<Application> applications = applicationRepository.findAll(Sort.by("id"));
        return applications.stream()
                .map(application -> mapToDTO(application, new ApplicationDTO()))
                .toList();
    }

    public ApplicationDTO get(final Long id) {
        return applicationRepository.findById(id)
                .map(application -> mapToDTO(application, new ApplicationDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final ApplicationDTO applicationDTO) {
        final Application application = new Application();
        mapToEntity(applicationDTO, application);
        return applicationRepository.save(application).getId();
    }

    public void update(final Long id, final ApplicationDTO applicationDTO) {
        final Application application = applicationRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(applicationDTO, application);
        applicationRepository.save(application);
    }

    public void delete(final Long id) {
        applicationRepository.deleteById(id);
    }

    private ApplicationDTO mapToDTO(final Application application,
            final ApplicationDTO applicationDTO) {
        applicationDTO.setId(application.getId());
        applicationDTO.setName(application.getName());
        applicationDTO.setAppCode(application.getAppCode());
        return applicationDTO;
    }

    private Application mapToEntity(final ApplicationDTO applicationDTO,
            final Application application) {
        application.setName(applicationDTO.getName());
        application.setAppCode(applicationDTO.getAppCode());
        return application;
    }

    public boolean nameExists(final String name) {
        return applicationRepository.existsByNameIgnoreCase(name);
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Application application = applicationRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Instance applicationInstance = instanceRepository.findFirstByApplication(application);
        if (applicationInstance != null) {
            referencedWarning.setKey("application.instance.application.referenced");
            referencedWarning.addParam(applicationInstance.getId());
            return referencedWarning;
        }
        return null;
    }

}
