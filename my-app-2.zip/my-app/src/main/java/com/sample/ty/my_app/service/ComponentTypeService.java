package com.sample.ty.my_app.service;

import com.sample.ty.my_app.domain.Component;
import com.sample.ty.my_app.domain.ComponentType;
import com.sample.ty.my_app.model.ComponentTypeDTO;
import com.sample.ty.my_app.repos.ComponentRepository;
import com.sample.ty.my_app.repos.ComponentTypeRepository;
import com.sample.ty.my_app.util.NotFoundException;
import com.sample.ty.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ComponentTypeService {

    private final ComponentTypeRepository componentTypeRepository;
    private final ComponentRepository componentRepository;

    public ComponentTypeService(final ComponentTypeRepository componentTypeRepository,
            final ComponentRepository componentRepository) {
        this.componentTypeRepository = componentTypeRepository;
        this.componentRepository = componentRepository;
    }

    public List<ComponentTypeDTO> findAll() {
        final List<ComponentType> componentTypes = componentTypeRepository.findAll(Sort.by("id"));
        return componentTypes.stream()
                .map(componentType -> mapToDTO(componentType, new ComponentTypeDTO()))
                .toList();
    }

    public ComponentTypeDTO get(final Long id) {
        return componentTypeRepository.findById(id)
                .map(componentType -> mapToDTO(componentType, new ComponentTypeDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final ComponentTypeDTO componentTypeDTO) {
        final ComponentType componentType = new ComponentType();
        mapToEntity(componentTypeDTO, componentType);
        return componentTypeRepository.save(componentType).getId();
    }

    public void update(final Long id, final ComponentTypeDTO componentTypeDTO) {
        final ComponentType componentType = componentTypeRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(componentTypeDTO, componentType);
        componentTypeRepository.save(componentType);
    }

    public void delete(final Long id) {
        componentTypeRepository.deleteById(id);
    }

    private ComponentTypeDTO mapToDTO(final ComponentType componentType,
            final ComponentTypeDTO componentTypeDTO) {
        componentTypeDTO.setId(componentType.getId());
        componentTypeDTO.setName(componentType.getName());
        return componentTypeDTO;
    }

    private ComponentType mapToEntity(final ComponentTypeDTO componentTypeDTO,
            final ComponentType componentType) {
        componentType.setName(componentTypeDTO.getName());
        return componentType;
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final ComponentType componentType = componentTypeRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Component componentTypeComponent = componentRepository.findFirstByComponentType(componentType);
        if (componentTypeComponent != null) {
            referencedWarning.setKey("componentType.component.componentType.referenced");
            referencedWarning.addParam(componentTypeComponent.getId());
            return referencedWarning;
        }
        return null;
    }

}
