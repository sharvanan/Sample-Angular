package com.sample.ty.my_app.rest;

import com.sample.ty.my_app.domain.Deployment;
import com.sample.ty.my_app.domain.Instance;
import com.sample.ty.my_app.model.DeploymentDTO;
import com.sample.ty.my_app.repos.DeploymentRepository;
import com.sample.ty.my_app.repos.InstanceRepository;
import com.sample.ty.my_app.service.DeploymentService;
import com.sample.ty.my_app.util.CustomCollectors;
import com.sample.ty.my_app.util.ReferencedException;
import com.sample.ty.my_app.util.ReferencedWarning;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/deployments", produces = MediaType.APPLICATION_JSON_VALUE)
public class DeploymentResource {

    private final DeploymentService deploymentService;
    private final InstanceRepository instanceRepository;
    private final DeploymentRepository deploymentRepository;

    public DeploymentResource(final DeploymentService deploymentService,
            final InstanceRepository instanceRepository,
            final DeploymentRepository deploymentRepository) {
        this.deploymentService = deploymentService;
        this.instanceRepository = instanceRepository;
        this.deploymentRepository = deploymentRepository;
    }

    @GetMapping
    public ResponseEntity<List<DeploymentDTO>> getAllDeployments() {
        return ResponseEntity.ok(deploymentService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<DeploymentDTO> getDeployment(@PathVariable(name = "id") final Long id) {
        return ResponseEntity.ok(deploymentService.get(id));
    }

    @PostMapping
    @ApiResponse(responseCode = "201")
    public ResponseEntity<Long> createDeployment(
            @RequestBody @Valid final DeploymentDTO deploymentDTO) {
        final Long createdId = deploymentService.create(deploymentDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Long> updateDeployment(@PathVariable(name = "id") final Long id,
            @RequestBody @Valid final DeploymentDTO deploymentDTO) {
        deploymentService.update(id, deploymentDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    @ApiResponse(responseCode = "204")
    public ResponseEntity<Void> deleteDeployment(@PathVariable(name = "id") final Long id) {
        final ReferencedWarning referencedWarning = deploymentService.getReferencedWarning(id);
        if (referencedWarning != null) {
            throw new ReferencedException(referencedWarning);
        }
        deploymentService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/instanceValues")
    public ResponseEntity<Map<Long, String>> getInstanceValues() {
        return ResponseEntity.ok(instanceRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Instance::getId, Instance::getInstanceName)));
    }

    @GetMapping("/deploymentsValues")
    public ResponseEntity<Map<Long, String>> getDeploymentsValues() {
        return ResponseEntity.ok(deploymentRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Deployment::getId, Deployment::getName)));
    }

}
