package com.sample.ty.my_app.service;

import com.sample.ty.my_app.domain.Application;
import com.sample.ty.my_app.domain.Deployment;
import com.sample.ty.my_app.domain.Instance;
import com.sample.ty.my_app.model.InstanceDTO;
import com.sample.ty.my_app.repos.ApplicationRepository;
import com.sample.ty.my_app.repos.DeploymentRepository;
import com.sample.ty.my_app.repos.InstanceRepository;
import com.sample.ty.my_app.util.NotFoundException;
import com.sample.ty.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class InstanceService {

    private final InstanceRepository instanceRepository;
    private final ApplicationRepository applicationRepository;
    private final DeploymentRepository deploymentRepository;

    public InstanceService(final InstanceRepository instanceRepository,
            final ApplicationRepository applicationRepository,
            final DeploymentRepository deploymentRepository) {
        this.instanceRepository = instanceRepository;
        this.applicationRepository = applicationRepository;
        this.deploymentRepository = deploymentRepository;
    }

    public List<InstanceDTO> findAll() {
        final List<Instance> instances = instanceRepository.findAll(Sort.by("id"));
        return instances.stream()
                .map(instance -> mapToDTO(instance, new InstanceDTO()))
                .toList();
    }

    public InstanceDTO get(final Long id) {
        return instanceRepository.findById(id)
                .map(instance -> mapToDTO(instance, new InstanceDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final InstanceDTO instanceDTO) {
        final Instance instance = new Instance();
        mapToEntity(instanceDTO, instance);
        return instanceRepository.save(instance).getId();
    }

    public void update(final Long id, final InstanceDTO instanceDTO) {
        final Instance instance = instanceRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(instanceDTO, instance);
        instanceRepository.save(instance);
    }

    public void delete(final Long id) {
        instanceRepository.deleteById(id);
    }

    private InstanceDTO mapToDTO(final Instance instance, final InstanceDTO instanceDTO) {
        instanceDTO.setId(instance.getId());
        instanceDTO.setInstanceName(instance.getInstanceName());
        instanceDTO.setDescription(instance.getDescription());
        instanceDTO.setApplication(instance.getApplication() == null ? null : instance.getApplication().getId());
        return instanceDTO;
    }

    private Instance mapToEntity(final InstanceDTO instanceDTO, final Instance instance) {
        instance.setInstanceName(instanceDTO.getInstanceName());
        instance.setDescription(instanceDTO.getDescription());
        final Application application = instanceDTO.getApplication() == null ? null : applicationRepository.findById(instanceDTO.getApplication())
                .orElseThrow(() -> new NotFoundException("application not found"));
        instance.setApplication(application);
        return instance;
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Instance instance = instanceRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Deployment instanceDeployment = deploymentRepository.findFirstByInstance(instance);
        if (instanceDeployment != null) {
            referencedWarning.setKey("instance.deployment.instance.referenced");
            referencedWarning.addParam(instanceDeployment.getId());
            return referencedWarning;
        }
        return null;
    }

}
