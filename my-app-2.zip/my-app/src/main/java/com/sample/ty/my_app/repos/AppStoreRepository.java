package com.sample.ty.my_app.repos;

import com.sample.ty.my_app.domain.AppStore;
import org.springframework.data.jpa.repository.JpaRepository;


public interface AppStoreRepository extends JpaRepository<AppStore, Long> {

    boolean existsByNameIgnoreCase(String name);

}
