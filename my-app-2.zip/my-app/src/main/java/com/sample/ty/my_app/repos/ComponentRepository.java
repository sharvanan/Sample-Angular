package com.sample.ty.my_app.repos;

import com.sample.ty.my_app.domain.Component;
import com.sample.ty.my_app.domain.ComponentType;
import com.sample.ty.my_app.domain.Deployment;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ComponentRepository extends JpaRepository<Component, Long> {

    Component findFirstByDeployment(Deployment deployment);

    Component findFirstByComponentType(ComponentType componentType);

    boolean existsByNameUniqueIgnoreCase(String nameUnique);

}
