package com.sample.ty.my_app.model;

import jakarta.validation.constraints.Size;


public class ComponentDTO {

    private Long id;

    @Size(max = 255)
    @ComponentNameUniqueUnique
    private String nameUnique;

    @Size(max = 255)
    private String name;

    private Long deployment;

    private Long componentType;

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getNameUnique() {
        return nameUnique;
    }

    public void setNameUnique(final String nameUnique) {
        this.nameUnique = nameUnique;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public Long getDeployment() {
        return deployment;
    }

    public void setDeployment(final Long deployment) {
        this.deployment = deployment;
    }

    public Long getComponentType() {
        return componentType;
    }

    public void setComponentType(final Long componentType) {
        this.componentType = componentType;
    }

}
