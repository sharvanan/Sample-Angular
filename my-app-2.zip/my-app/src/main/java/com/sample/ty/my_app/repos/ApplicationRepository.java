package com.sample.ty.my_app.repos;

import com.sample.ty.my_app.domain.Application;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ApplicationRepository extends JpaRepository<Application, Long> {

    boolean existsByNameIgnoreCase(String name);

}
