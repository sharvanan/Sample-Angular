package com.sample.ty.my_app.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;


public class AppStoreDTO {

    private Long id;

    @NotNull
    @Size(max = 255)
    @AppStoreNameUnique
    private String name;

    @Size(max = 255)
    private String type;

    private List<@Size(max = 255) String> continuity;

    private List<@Size(max = 255) String> integrity;

    private List<@Size(max = 255) String> traceability;

    private List<@Size(max = 255) String> availability;

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    public List<String> getContinuity() {
        return continuity;
    }

    public void setContinuity(final List<String> continuity) {
        this.continuity = continuity;
    }

    public List<String> getIntegrity() {
        return integrity;
    }

    public void setIntegrity(final List<String> integrity) {
        this.integrity = integrity;
    }

    public List<String> getTraceability() {
        return traceability;
    }

    public void setTraceability(final List<String> traceability) {
        this.traceability = traceability;
    }

    public List<String> getAvailability() {
        return availability;
    }

    public void setAvailability(final List<String> availability) {
        this.availability = availability;
    }

}
