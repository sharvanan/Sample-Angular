package com.sample.ty.my_app.repos;

import com.sample.ty.my_app.domain.Application;
import com.sample.ty.my_app.domain.Instance;
import org.springframework.data.jpa.repository.JpaRepository;


public interface InstanceRepository extends JpaRepository<Instance, Long> {

    Instance findFirstByApplication(Application application);

}
