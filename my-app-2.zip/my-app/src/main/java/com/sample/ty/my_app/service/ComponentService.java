package com.sample.ty.my_app.service;

import com.sample.ty.my_app.domain.Component;
import com.sample.ty.my_app.domain.ComponentType;
import com.sample.ty.my_app.domain.Deployment;
import com.sample.ty.my_app.domain.Status;
import com.sample.ty.my_app.model.ComponentDTO;
import com.sample.ty.my_app.repos.ComponentRepository;
import com.sample.ty.my_app.repos.ComponentTypeRepository;
import com.sample.ty.my_app.repos.DeploymentRepository;
import com.sample.ty.my_app.repos.StatusRepository;
import com.sample.ty.my_app.util.NotFoundException;
import com.sample.ty.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ComponentService {

    private final ComponentRepository componentRepository;
    private final DeploymentRepository deploymentRepository;
    private final ComponentTypeRepository componentTypeRepository;
    private final StatusRepository statusRepository;

    public ComponentService(final ComponentRepository componentRepository,
            final DeploymentRepository deploymentRepository,
            final ComponentTypeRepository componentTypeRepository,
            final StatusRepository statusRepository) {
        this.componentRepository = componentRepository;
        this.deploymentRepository = deploymentRepository;
        this.componentTypeRepository = componentTypeRepository;
        this.statusRepository = statusRepository;
    }

    public List<ComponentDTO> findAll() {
        final List<Component> components = componentRepository.findAll(Sort.by("id"));
        return components.stream()
                .map(component -> mapToDTO(component, new ComponentDTO()))
                .toList();
    }

    public ComponentDTO get(final Long id) {
        return componentRepository.findById(id)
                .map(component -> mapToDTO(component, new ComponentDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final ComponentDTO componentDTO) {
        final Component component = new Component();
        mapToEntity(componentDTO, component);
        return componentRepository.save(component).getId();
    }

    public void update(final Long id, final ComponentDTO componentDTO) {
        final Component component = componentRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(componentDTO, component);
        componentRepository.save(component);
    }

    public void delete(final Long id) {
        componentRepository.deleteById(id);
    }

    private ComponentDTO mapToDTO(final Component component, final ComponentDTO componentDTO) {
        componentDTO.setId(component.getId());
        componentDTO.setNameUnique(component.getNameUnique());
        componentDTO.setName(component.getName());
        componentDTO.setDeployment(component.getDeployment() == null ? null : component.getDeployment().getId());
        componentDTO.setComponentType(component.getComponentType() == null ? null : component.getComponentType().getId());
        return componentDTO;
    }

    private Component mapToEntity(final ComponentDTO componentDTO, final Component component) {
        component.setNameUnique(componentDTO.getNameUnique());
        component.setName(componentDTO.getName());
        final Deployment deployment = componentDTO.getDeployment() == null ? null : deploymentRepository.findById(componentDTO.getDeployment())
                .orElseThrow(() -> new NotFoundException("deployment not found"));
        component.setDeployment(deployment);
        final ComponentType componentType = componentDTO.getComponentType() == null ? null : componentTypeRepository.findById(componentDTO.getComponentType())
                .orElseThrow(() -> new NotFoundException("componentType not found"));
        component.setComponentType(componentType);
        return component;
    }

    public boolean nameUniqueExists(final String nameUnique) {
        return componentRepository.existsByNameUniqueIgnoreCase(nameUnique);
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Component component = componentRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Status componentStatus = statusRepository.findFirstByComponent(component);
        if (componentStatus != null) {
            referencedWarning.setKey("component.status.component.referenced");
            referencedWarning.addParam(componentStatus.getId());
            return referencedWarning;
        }
        return null;
    }

}
