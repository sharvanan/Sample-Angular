import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { ApplicationDTO } from 'app/application/application.model';


@Injectable({
  providedIn: 'root',
})
export class ApplicationService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/applications';

  getAllApplications() {
    return this.http.get<ApplicationDTO[]>(this.resourcePath);
  }

  getApplication(id: number) {
    return this.http.get<ApplicationDTO>(this.resourcePath + '/' + id);
  }

  createApplication(applicationDTO: ApplicationDTO) {
    return this.http.post<number>(this.resourcePath, applicationDTO);
  }

  updateApplication(id: number, applicationDTO: ApplicationDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, applicationDTO);
  }

  deleteApplication(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

}
