import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { ApplicationService } from 'app/application/application.service';
import { ApplicationDTO } from 'app/application/application.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';


@Component({
  selector: 'app-application-add',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './application-add.component.html'
})
export class ApplicationAddComponent {

  applicationService = inject(ApplicationService);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  addForm = new FormGroup({
    name: new FormControl(null, [Validators.required, Validators.maxLength(255)]),
    appCode: new FormControl(null, [Validators.required, Validators.maxLength(255)])
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      created: $localize`:@@application.create.success:Application was created successfully.`,
      APPLICATION_NAME_UNIQUE: $localize`:@@Exists.application.name:This Name is already taken.`
    };
    return messages[key];
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.addForm.markAllAsTouched();
    if (!this.addForm.valid) {
      return;
    }
    const data = new ApplicationDTO(this.addForm.value);
    this.applicationService.createApplication(data)
        .subscribe({
          next: () => this.router.navigate(['/applications'], {
            state: {
              msgSuccess: this.getMessage('created')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.addForm, this.getMessage)
        });
  }

}
