export class ApplicationDTO {

  constructor(data:Partial<ApplicationDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  name?: string|null;
  appCode?: string|null;

}
