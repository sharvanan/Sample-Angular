import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { ApplicationService } from 'app/application/application.service';
import { ApplicationDTO } from 'app/application/application.model';


@Component({
  selector: 'app-application-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './application-list.component.html'})
export class ApplicationListComponent implements OnInit, OnDestroy {

  applicationService = inject(ApplicationService);
  errorHandler = inject(ErrorHandler);
  router = inject(Router);
  applications?: ApplicationDTO[];
  navigationSubscription?: Subscription;

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      confirm: $localize`:@@delete.confirm:Do you really want to delete this element? This cannot be undone.`,
      deleted: $localize`:@@application.delete.success:Application was removed successfully.`,
      'application.instance.application.referenced': $localize`:@@application.instance.application.referenced:This entity is still referenced by Instance ${details?.id} via field Application.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.loadData();
    this.navigationSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.loadData();
      }
    });
  }

  ngOnDestroy() {
    this.navigationSubscription!.unsubscribe();
  }
  
  loadData() {
    this.applicationService.getAllApplications()
        .subscribe({
          next: (data) => this.applications = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  confirmDelete(id: number) {
    if (confirm(this.getMessage('confirm'))) {
      this.applicationService.deleteApplication(id)
          .subscribe({
            next: () => this.router.navigate(['/applications'], {
              state: {
                msgInfo: this.getMessage('deleted')
              }
            }),
            error: (error) => {
              if (error.error?.code === 'REFERENCED') {
                const messageParts = error.error.message.split(',');
                this.router.navigate(['/applications'], {
                  state: {
                    msgError: this.getMessage(messageParts[0], { id: messageParts[1] })
                  }
                });
                return;
              }
              this.errorHandler.handleServerError(error.error)
            }
          });
    }
  }

}
