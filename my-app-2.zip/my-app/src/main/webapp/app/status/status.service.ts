import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { StatusDTO } from 'app/status/status.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class StatusService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/statuses';

  getAllStatuses() {
    return this.http.get<StatusDTO[]>(this.resourcePath);
  }

  getStatus(id: number) {
    return this.http.get<StatusDTO>(this.resourcePath + '/' + id);
  }

  createStatus(statusDTO: StatusDTO) {
    return this.http.post<number>(this.resourcePath, statusDTO);
  }

  updateStatus(id: number, statusDTO: StatusDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, statusDTO);
  }

  deleteStatus(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getComponentValues() {
    return this.http.get<Record<string,number>>(this.resourcePath + '/componentValues')
        .pipe(map(transformRecordToMap));
  }

}
