export class StatusDTO {

  constructor(data:Partial<StatusDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  name?: string|null;
  component?: number|null;

}
