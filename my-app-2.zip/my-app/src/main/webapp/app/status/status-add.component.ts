import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { StatusService } from 'app/status/status.service';
import { StatusDTO } from 'app/status/status.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';


@Component({
  selector: 'app-status-add',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './status-add.component.html'
})
export class StatusAddComponent implements OnInit {

  statusService = inject(StatusService);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  componentValues?: Map<number,string>;

  addForm = new FormGroup({
    name: new FormControl(null, [Validators.required, Validators.maxLength(255)]),
    component: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      created: $localize`:@@status.create.success:Status was created successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.statusService.getComponentValues()
        .subscribe({
          next: (data) => this.componentValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.addForm.markAllAsTouched();
    if (!this.addForm.valid) {
      return;
    }
    const data = new StatusDTO(this.addForm.value);
    this.statusService.createStatus(data)
        .subscribe({
          next: () => this.router.navigate(['/statuses'], {
            state: {
              msgSuccess: this.getMessage('created')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.addForm, this.getMessage)
        });
  }

}
