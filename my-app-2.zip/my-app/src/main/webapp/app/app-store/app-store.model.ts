export class AppStoreDTO {

  constructor(data:Partial<AppStoreDTO>) {
    Object.assign(this, data);
    if (data.continuity) {
      this.continuity = JSON.parse(data.continuity);
    }
    if (data.integrity) {
      this.integrity = JSON.parse(data.integrity);
    }
    if (data.traceability) {
      this.traceability = JSON.parse(data.traceability);
    }
    if (data.availability) {
      this.availability = JSON.parse(data.availability);
    }
  }

  id?: number|null;
  name?: string|null;
  type?: string|null;
  continuity?: any|null;
  integrity?: any|null;
  traceability?: any|null;
  availability?: any|null;

}
