import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { AppStoreDTO } from 'app/app-store/app-store.model';


@Injectable({
  providedIn: 'root',
})
export class AppStoreService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/appStores';

  getAllAppStores() {
    return this.http.get<AppStoreDTO[]>(this.resourcePath);
  }

  getAppStore(id: number) {
    return this.http.get<AppStoreDTO>(this.resourcePath + '/' + id);
  }

  createAppStore(appStoreDTO: AppStoreDTO) {
    return this.http.post<number>(this.resourcePath, appStoreDTO);
  }

  updateAppStore(id: number, appStoreDTO: AppStoreDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, appStoreDTO);
  }

  deleteAppStore(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

}
