import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { AppStoreService } from 'app/app-store/app-store.service';
import { AppStoreDTO } from 'app/app-store/app-store.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { validJson } from 'app/common/utils';


@Component({
  selector: 'app-app-store-add',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './app-store-add.component.html'
})
export class AppStoreAddComponent {

  appStoreService = inject(AppStoreService);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  addForm = new FormGroup({
    name: new FormControl(null, [Validators.required, Validators.maxLength(255)]),
    type: new FormControl(null, [Validators.maxLength(255)]),
    continuity: new FormControl(null, [validJson]),
    integrity: new FormControl(null, [validJson]),
    traceability: new FormControl(null, [validJson]),
    availability: new FormControl(null, [validJson])
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      created: $localize`:@@appStore.create.success:App Store was created successfully.`,
      APP_STORE_NAME_UNIQUE: $localize`:@@Exists.appStore.name:This Name is already taken.`
    };
    return messages[key];
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.addForm.markAllAsTouched();
    if (!this.addForm.valid) {
      return;
    }
    const data = new AppStoreDTO(this.addForm.value);
    this.appStoreService.createAppStore(data)
        .subscribe({
          next: () => this.router.navigate(['/appStores'], {
            state: {
              msgSuccess: this.getMessage('created')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.addForm, this.getMessage)
        });
  }

}
