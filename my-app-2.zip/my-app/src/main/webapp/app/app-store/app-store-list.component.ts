import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { AppStoreService } from 'app/app-store/app-store.service';
import { AppStoreDTO } from 'app/app-store/app-store.model';


@Component({
  selector: 'app-app-store-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './app-store-list.component.html'})
export class AppStoreListComponent implements OnInit, OnDestroy {

  appStoreService = inject(AppStoreService);
  errorHandler = inject(ErrorHandler);
  router = inject(Router);
  appStores?: AppStoreDTO[];
  navigationSubscription?: Subscription;

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      confirm: $localize`:@@delete.confirm:Do you really want to delete this element? This cannot be undone.`,
      deleted: $localize`:@@appStore.delete.success:App Store was removed successfully.`    };
    return messages[key];
  }

  ngOnInit() {
    this.loadData();
    this.navigationSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.loadData();
      }
    });
  }

  ngOnDestroy() {
    this.navigationSubscription!.unsubscribe();
  }
  
  loadData() {
    this.appStoreService.getAllAppStores()
        .subscribe({
          next: (data) => this.appStores = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  confirmDelete(id: number) {
    if (confirm(this.getMessage('confirm'))) {
      this.appStoreService.deleteAppStore(id)
          .subscribe({
            next: () => this.router.navigate(['/appStores'], {
              state: {
                msgInfo: this.getMessage('deleted')
              }
            }),
            error: (error) => this.errorHandler.handleServerError(error.error)
          });
    }
  }

}
