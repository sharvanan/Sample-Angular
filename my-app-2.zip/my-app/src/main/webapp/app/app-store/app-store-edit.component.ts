import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { AppStoreService } from 'app/app-store/app-store.service';
import { AppStoreDTO } from 'app/app-store/app-store.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { updateForm, validJson } from 'app/common/utils';


@Component({
  selector: 'app-app-store-edit',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './app-store-edit.component.html'
})
export class AppStoreEditComponent implements OnInit {

  appStoreService = inject(AppStoreService);
  route = inject(ActivatedRoute);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  currentId?: number;

  editForm = new FormGroup({
    id: new FormControl({ value: null, disabled: true }),
    name: new FormControl(null, [Validators.required, Validators.maxLength(255)]),
    type: new FormControl(null, [Validators.maxLength(255)]),
    continuity: new FormControl(null, [validJson]),
    integrity: new FormControl(null, [validJson]),
    traceability: new FormControl(null, [validJson]),
    availability: new FormControl(null, [validJson])
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      updated: $localize`:@@appStore.update.success:App Store was updated successfully.`,
      APP_STORE_NAME_UNIQUE: $localize`:@@Exists.appStore.name:This Name is already taken.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.currentId = +this.route.snapshot.params['id'];
    this.appStoreService.getAppStore(this.currentId!)
        .subscribe({
          next: (data) => updateForm(this.editForm, data),
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.editForm.markAllAsTouched();
    if (!this.editForm.valid) {
      return;
    }
    const data = new AppStoreDTO(this.editForm.value);
    this.appStoreService.updateAppStore(this.currentId!, data)
        .subscribe({
          next: () => this.router.navigate(['/appStores'], {
            state: {
              msgSuccess: this.getMessage('updated')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.editForm, this.getMessage)
        });
  }

}
