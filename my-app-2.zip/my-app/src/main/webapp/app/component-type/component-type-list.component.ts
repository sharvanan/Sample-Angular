import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { ComponentTypeService } from 'app/component-type/component-type.service';
import { ComponentTypeDTO } from 'app/component-type/component-type.model';


@Component({
  selector: 'app-component-type-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './component-type-list.component.html'})
export class ComponentTypeListComponent implements OnInit, OnDestroy {

  componentTypeService = inject(ComponentTypeService);
  errorHandler = inject(ErrorHandler);
  router = inject(Router);
  componentTypes?: ComponentTypeDTO[];
  navigationSubscription?: Subscription;

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      confirm: $localize`:@@delete.confirm:Do you really want to delete this element? This cannot be undone.`,
      deleted: $localize`:@@componentType.delete.success:Component Type was removed successfully.`,
      'componentType.component.componentType.referenced': $localize`:@@componentType.component.componentType.referenced:This entity is still referenced by Component ${details?.id} via field Component Type.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.loadData();
    this.navigationSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.loadData();
      }
    });
  }

  ngOnDestroy() {
    this.navigationSubscription!.unsubscribe();
  }
  
  loadData() {
    this.componentTypeService.getAllComponentTypes()
        .subscribe({
          next: (data) => this.componentTypes = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  confirmDelete(id: number) {
    if (confirm(this.getMessage('confirm'))) {
      this.componentTypeService.deleteComponentType(id)
          .subscribe({
            next: () => this.router.navigate(['/componentTypes'], {
              state: {
                msgInfo: this.getMessage('deleted')
              }
            }),
            error: (error) => {
              if (error.error?.code === 'REFERENCED') {
                const messageParts = error.error.message.split(',');
                this.router.navigate(['/componentTypes'], {
                  state: {
                    msgError: this.getMessage(messageParts[0], { id: messageParts[1] })
                  }
                });
                return;
              }
              this.errorHandler.handleServerError(error.error)
            }
          });
    }
  }

}
