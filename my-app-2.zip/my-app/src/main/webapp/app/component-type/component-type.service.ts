import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { ComponentTypeDTO } from 'app/component-type/component-type.model';


@Injectable({
  providedIn: 'root',
})
export class ComponentTypeService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/componentTypes';

  getAllComponentTypes() {
    return this.http.get<ComponentTypeDTO[]>(this.resourcePath);
  }

  getComponentType(id: number) {
    return this.http.get<ComponentTypeDTO>(this.resourcePath + '/' + id);
  }

  createComponentType(componentTypeDTO: ComponentTypeDTO) {
    return this.http.post<number>(this.resourcePath, componentTypeDTO);
  }

  updateComponentType(id: number, componentTypeDTO: ComponentTypeDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, componentTypeDTO);
  }

  deleteComponentType(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

}
