export class ComponentTypeDTO {

  constructor(data:Partial<ComponentTypeDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  name?: string|null;

}
