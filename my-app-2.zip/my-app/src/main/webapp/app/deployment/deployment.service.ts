import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { DeploymentDTO } from 'app/deployment/deployment.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class DeploymentService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/deployments';

  getAllDeployments() {
    return this.http.get<DeploymentDTO[]>(this.resourcePath);
  }

  getDeployment(id: number) {
    return this.http.get<DeploymentDTO>(this.resourcePath + '/' + id);
  }

  createDeployment(deploymentDTO: DeploymentDTO) {
    return this.http.post<number>(this.resourcePath, deploymentDTO);
  }

  updateDeployment(id: number, deploymentDTO: DeploymentDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, deploymentDTO);
  }

  deleteDeployment(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getInstanceValues() {
    return this.http.get<Record<string,string>>(this.resourcePath + '/instanceValues')
        .pipe(map(transformRecordToMap));
  }

  getDeploymentsValues() {
    return this.http.get<Record<string,string>>(this.resourcePath + '/deploymentsValues')
        .pipe(map(transformRecordToMap));
  }

}
