export class DeploymentDTO {

  constructor(data:Partial<DeploymentDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  name?: string|null;
  instance?: number|null;
  deployments?: number[]|null;

}
