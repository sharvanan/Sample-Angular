import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { DeploymentService } from 'app/deployment/deployment.service';
import { DeploymentDTO } from 'app/deployment/deployment.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { updateForm } from 'app/common/utils';


@Component({
  selector: 'app-deployment-edit',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './deployment-edit.component.html'
})
export class DeploymentEditComponent implements OnInit {

  deploymentService = inject(DeploymentService);
  route = inject(ActivatedRoute);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  instanceValues?: Map<number,string>;
  deploymentsValues?: Map<number,string>;
  currentId?: number;

  editForm = new FormGroup({
    id: new FormControl({ value: null, disabled: true }),
    name: new FormControl(null, [Validators.required, Validators.maxLength(255)]),
    instance: new FormControl(null),
    deployments: new FormControl([])
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      updated: $localize`:@@deployment.update.success:Deployment was updated successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.currentId = +this.route.snapshot.params['id'];
    this.deploymentService.getInstanceValues()
        .subscribe({
          next: (data) => this.instanceValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.deploymentService.getDeploymentsValues()
        .subscribe({
          next: (data) => this.deploymentsValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.deploymentService.getDeployment(this.currentId!)
        .subscribe({
          next: (data) => updateForm(this.editForm, data),
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.editForm.markAllAsTouched();
    if (!this.editForm.valid) {
      return;
    }
    const data = new DeploymentDTO(this.editForm.value);
    this.deploymentService.updateDeployment(this.currentId!, data)
        .subscribe({
          next: () => this.router.navigate(['/deployments'], {
            state: {
              msgSuccess: this.getMessage('updated')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.editForm, this.getMessage)
        });
  }

}
