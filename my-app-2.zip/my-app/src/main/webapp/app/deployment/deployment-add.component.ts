import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { DeploymentService } from 'app/deployment/deployment.service';
import { DeploymentDTO } from 'app/deployment/deployment.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';


@Component({
  selector: 'app-deployment-add',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './deployment-add.component.html'
})
export class DeploymentAddComponent implements OnInit {

  deploymentService = inject(DeploymentService);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  instanceValues?: Map<number,string>;
  deploymentsValues?: Map<number,string>;

  addForm = new FormGroup({
    name: new FormControl(null, [Validators.required, Validators.maxLength(255)]),
    instance: new FormControl(null),
    deployments: new FormControl([])
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      created: $localize`:@@deployment.create.success:Deployment was created successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.deploymentService.getInstanceValues()
        .subscribe({
          next: (data) => this.instanceValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.deploymentService.getDeploymentsValues()
        .subscribe({
          next: (data) => this.deploymentsValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.addForm.markAllAsTouched();
    if (!this.addForm.valid) {
      return;
    }
    const data = new DeploymentDTO(this.addForm.value);
    this.deploymentService.createDeployment(data)
        .subscribe({
          next: () => this.router.navigate(['/deployments'], {
            state: {
              msgSuccess: this.getMessage('created')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.addForm, this.getMessage)
        });
  }

}
