import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { InstanceService } from 'app/instance/instance.service';
import { InstanceDTO } from 'app/instance/instance.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';


@Component({
  selector: 'app-instance-add',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './instance-add.component.html'
})
export class InstanceAddComponent implements OnInit {

  instanceService = inject(InstanceService);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  applicationValues?: Map<number,string>;

  addForm = new FormGroup({
    instanceName: new FormControl(null, [Validators.required, Validators.maxLength(255)]),
    description: new FormControl(null, [Validators.maxLength(255)]),
    application: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      created: $localize`:@@instance.create.success:Instance was created successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.instanceService.getApplicationValues()
        .subscribe({
          next: (data) => this.applicationValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.addForm.markAllAsTouched();
    if (!this.addForm.valid) {
      return;
    }
    const data = new InstanceDTO(this.addForm.value);
    this.instanceService.createInstance(data)
        .subscribe({
          next: () => this.router.navigate(['/instances'], {
            state: {
              msgSuccess: this.getMessage('created')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.addForm, this.getMessage)
        });
  }

}
