import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { InstanceService } from 'app/instance/instance.service';
import { InstanceDTO } from 'app/instance/instance.model';


@Component({
  selector: 'app-instance-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './instance-list.component.html'})
export class InstanceListComponent implements OnInit, OnDestroy {

  instanceService = inject(InstanceService);
  errorHandler = inject(ErrorHandler);
  router = inject(Router);
  instances?: InstanceDTO[];
  navigationSubscription?: Subscription;

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      confirm: $localize`:@@delete.confirm:Do you really want to delete this element? This cannot be undone.`,
      deleted: $localize`:@@instance.delete.success:Instance was removed successfully.`,
      'instance.deployment.instance.referenced': $localize`:@@instance.deployment.instance.referenced:This entity is still referenced by Deployment ${details?.id} via field Instance.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.loadData();
    this.navigationSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.loadData();
      }
    });
  }

  ngOnDestroy() {
    this.navigationSubscription!.unsubscribe();
  }
  
  loadData() {
    this.instanceService.getAllInstances()
        .subscribe({
          next: (data) => this.instances = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  confirmDelete(id: number) {
    if (confirm(this.getMessage('confirm'))) {
      this.instanceService.deleteInstance(id)
          .subscribe({
            next: () => this.router.navigate(['/instances'], {
              state: {
                msgInfo: this.getMessage('deleted')
              }
            }),
            error: (error) => {
              if (error.error?.code === 'REFERENCED') {
                const messageParts = error.error.message.split(',');
                this.router.navigate(['/instances'], {
                  state: {
                    msgError: this.getMessage(messageParts[0], { id: messageParts[1] })
                  }
                });
                return;
              }
              this.errorHandler.handleServerError(error.error)
            }
          });
    }
  }

}
