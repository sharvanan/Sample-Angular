export class InstanceDTO {

  constructor(data:Partial<InstanceDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  instanceName?: string|null;
  description?: string|null;
  application?: number|null;

}
