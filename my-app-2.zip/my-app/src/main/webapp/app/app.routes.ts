import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ApplicationListComponent } from './application/application-list.component';
import { ApplicationAddComponent } from './application/application-add.component';
import { ApplicationEditComponent } from './application/application-edit.component';
import { InstanceListComponent } from './instance/instance-list.component';
import { InstanceAddComponent } from './instance/instance-add.component';
import { InstanceEditComponent } from './instance/instance-edit.component';
import { DeploymentListComponent } from './deployment/deployment-list.component';
import { DeploymentAddComponent } from './deployment/deployment-add.component';
import { DeploymentEditComponent } from './deployment/deployment-edit.component';
import { AppStoreListComponent } from './app-store/app-store-list.component';
import { AppStoreAddComponent } from './app-store/app-store-add.component';
import { AppStoreEditComponent } from './app-store/app-store-edit.component';
import { ComponentListComponent } from './component/component-list.component';
import { ComponentAddComponent } from './component/component-add.component';
import { ComponentEditComponent } from './component/component-edit.component';
import { ComponentTypeListComponent } from './component-type/component-type-list.component';
import { ComponentTypeAddComponent } from './component-type/component-type-add.component';
import { ComponentTypeEditComponent } from './component-type/component-type-edit.component';
import { StatusListComponent } from './status/status-list.component';
import { StatusAddComponent } from './status/status-add.component';
import { StatusEditComponent } from './status/status-edit.component';
import { ErrorComponent } from './error/error.component';


export const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    title: $localize`:@@home.index.headline:Welcome to your new app!`
  },
  {
    path: 'applications',
    component: ApplicationListComponent,
    title: $localize`:@@application.list.headline:Applications`
  },
  {
    path: 'applications/add',
    component: ApplicationAddComponent,
    title: $localize`:@@application.add.headline:Add Application`
  },
  {
    path: 'applications/edit/:id',
    component: ApplicationEditComponent,
    title: $localize`:@@application.edit.headline:Edit Application`
  },
  {
    path: 'instances',
    component: InstanceListComponent,
    title: $localize`:@@instance.list.headline:Instances`
  },
  {
    path: 'instances/add',
    component: InstanceAddComponent,
    title: $localize`:@@instance.add.headline:Add Instance`
  },
  {
    path: 'instances/edit/:id',
    component: InstanceEditComponent,
    title: $localize`:@@instance.edit.headline:Edit Instance`
  },
  {
    path: 'deployments',
    component: DeploymentListComponent,
    title: $localize`:@@deployment.list.headline:Deployments`
  },
  {
    path: 'deployments/add',
    component: DeploymentAddComponent,
    title: $localize`:@@deployment.add.headline:Add Deployment`
  },
  {
    path: 'deployments/edit/:id',
    component: DeploymentEditComponent,
    title: $localize`:@@deployment.edit.headline:Edit Deployment`
  },
  {
    path: 'appStores',
    component: AppStoreListComponent,
    title: $localize`:@@appStore.list.headline:App Stores`
  },
  {
    path: 'appStores/add',
    component: AppStoreAddComponent,
    title: $localize`:@@appStore.add.headline:Add App Store`
  },
  {
    path: 'appStores/edit/:id',
    component: AppStoreEditComponent,
    title: $localize`:@@appStore.edit.headline:Edit App Store`
  },
  {
    path: 'components',
    component: ComponentListComponent,
    title: $localize`:@@component.list.headline:Components`
  },
  {
    path: 'components/add',
    component: ComponentAddComponent,
    title: $localize`:@@component.add.headline:Add Component`
  },
  {
    path: 'components/edit/:id',
    component: ComponentEditComponent,
    title: $localize`:@@component.edit.headline:Edit Component`
  },
  {
    path: 'componentTypes',
    component: ComponentTypeListComponent,
    title: $localize`:@@componentType.list.headline:Component Types`
  },
  {
    path: 'componentTypes/add',
    component: ComponentTypeAddComponent,
    title: $localize`:@@componentType.add.headline:Add Component Type`
  },
  {
    path: 'componentTypes/edit/:id',
    component: ComponentTypeEditComponent,
    title: $localize`:@@componentType.edit.headline:Edit Component Type`
  },
  {
    path: 'statuses',
    component: StatusListComponent,
    title: $localize`:@@status.list.headline:Statuses`
  },
  {
    path: 'statuses/add',
    component: StatusAddComponent,
    title: $localize`:@@status.add.headline:Add Status`
  },
  {
    path: 'statuses/edit/:id',
    component: StatusEditComponent,
    title: $localize`:@@status.edit.headline:Edit Status`
  },
  {
    path: 'error',
    component: ErrorComponent,
    title: $localize`:@@error.headline:Error`
  },
  {
    path: '**',
    component: ErrorComponent,
    title: $localize`:@@notFound.headline:Page not found`
  }
];
