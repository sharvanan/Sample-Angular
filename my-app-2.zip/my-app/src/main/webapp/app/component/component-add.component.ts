import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { ComponentService } from 'app/component/component.service';
import { ComponentDTO } from 'app/component/component.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';


@Component({
  selector: 'app-component-add',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './component-add.component.html'
})
export class ComponentAddComponent implements OnInit {

  componentService = inject(ComponentService);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  deploymentValues?: Map<number,string>;
  componentTypeValues?: Map<number,string>;

  addForm = new FormGroup({
    nameUnique: new FormControl(null, [Validators.maxLength(255)]),
    name: new FormControl(null, [Validators.maxLength(255)]),
    deployment: new FormControl(null),
    componentType: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      created: $localize`:@@component.create.success:Component was created successfully.`,
      COMPONENT_NAME_UNIQUE_UNIQUE: $localize`:@@Exists.component.nameUnique:This Name Unique is already taken.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.componentService.getDeploymentValues()
        .subscribe({
          next: (data) => this.deploymentValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.componentService.getComponentTypeValues()
        .subscribe({
          next: (data) => this.componentTypeValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.addForm.markAllAsTouched();
    if (!this.addForm.valid) {
      return;
    }
    const data = new ComponentDTO(this.addForm.value);
    this.componentService.createComponent(data)
        .subscribe({
          next: () => this.router.navigate(['/components'], {
            state: {
              msgSuccess: this.getMessage('created')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.addForm, this.getMessage)
        });
  }

}
