export class ComponentDTO {

  constructor(data:Partial<ComponentDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  nameUnique?: string|null;
  name?: string|null;
  deployment?: number|null;
  componentType?: number|null;

}
