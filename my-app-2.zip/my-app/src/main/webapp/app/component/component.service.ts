import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { ComponentDTO } from 'app/component/component.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class ComponentService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/components';

  getAllComponents() {
    return this.http.get<ComponentDTO[]>(this.resourcePath);
  }

  getComponent(id: number) {
    return this.http.get<ComponentDTO>(this.resourcePath + '/' + id);
  }

  createComponent(componentDTO: ComponentDTO) {
    return this.http.post<number>(this.resourcePath, componentDTO);
  }

  updateComponent(id: number, componentDTO: ComponentDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, componentDTO);
  }

  deleteComponent(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getDeploymentValues() {
    return this.http.get<Record<string,string>>(this.resourcePath + '/deploymentValues')
        .pipe(map(transformRecordToMap));
  }

  getComponentTypeValues() {
    return this.http.get<Record<string,string>>(this.resourcePath + '/componentTypeValues')
        .pipe(map(transformRecordToMap));
  }

}
