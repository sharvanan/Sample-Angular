import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { ComponentService } from 'app/component/component.service';
import { ComponentDTO } from 'app/component/component.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { updateForm } from 'app/common/utils';


@Component({
  selector: 'app-component-edit',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './component-edit.component.html'
})
export class ComponentEditComponent implements OnInit {

  componentService = inject(ComponentService);
  route = inject(ActivatedRoute);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  deploymentValues?: Map<number,string>;
  componentTypeValues?: Map<number,string>;
  currentId?: number;

  editForm = new FormGroup({
    id: new FormControl({ value: null, disabled: true }),
    nameUnique: new FormControl(null, [Validators.maxLength(255)]),
    name: new FormControl(null, [Validators.maxLength(255)]),
    deployment: new FormControl(null),
    componentType: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      updated: $localize`:@@component.update.success:Component was updated successfully.`,
      COMPONENT_NAME_UNIQUE_UNIQUE: $localize`:@@Exists.component.nameUnique:This Name Unique is already taken.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.currentId = +this.route.snapshot.params['id'];
    this.componentService.getDeploymentValues()
        .subscribe({
          next: (data) => this.deploymentValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.componentService.getComponentTypeValues()
        .subscribe({
          next: (data) => this.componentTypeValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.componentService.getComponent(this.currentId!)
        .subscribe({
          next: (data) => updateForm(this.editForm, data),
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.editForm.markAllAsTouched();
    if (!this.editForm.valid) {
      return;
    }
    const data = new ComponentDTO(this.editForm.value);
    this.componentService.updateComponent(this.currentId!, data)
        .subscribe({
          next: () => this.router.navigate(['/components'], {
            state: {
              msgSuccess: this.getMessage('updated')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.editForm, this.getMessage)
        });
  }

}
